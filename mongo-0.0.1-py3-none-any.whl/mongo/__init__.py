from . import mongo

__version__ = '0.0.1'

Mongo = mongo.Mongo

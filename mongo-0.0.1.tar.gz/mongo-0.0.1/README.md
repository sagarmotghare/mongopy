# Mongo

A simple package to do operation on MongoDB database

# Support

Having problems or got a question?

- Ask more detailed questions on the mail: [sagarmotghare@proton.me](mailto:%20sagarmotghare@proton.me)
- Use [Github](https://github.com/sagarmotghare/mongo) for submitting issues and pull requests.

# Changelog

## 0.0.1 (released June 10, 2023)

- First version including all functions
